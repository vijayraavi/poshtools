Describe "Get-Function" {
  Context "Function Exists" {
		It "Should Return" {
		
		}
    }
}